import requests
from requests.auth import HTTPBasicAuth
import time

# Configuration File Path
config_file_path = '/root/ddclient/ddclient.conf'

def read_config(file_path):
    config = {}
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                config[key.strip()] = value.strip()
    return config

# Read configuration from file
config = read_config(config_file_path)

# Extract configuration values
username = config.get('username')
password = config.get('password')
hostname = config.get('hostname')
ddns_key = config.get('ddns_key')
update_interval = 300  # Interval in seconds (e.g., 300 seconds = 5 minutes)

# Get the current public IP address
def get_public_ip():
    try:
        response = requests.get('http://ifconfig.me')
        response.raise_for_status()
        return response.text.strip()
    except requests.RequestException as e:
        print(f"Error fetching IP address: {e}")
        return None

# Update the No-IP hostname
def update_noip(ip_address):
    update_url = f'https://dynupdate.no-ip.com/nic/update?hostname={hostname}&myip={ip_address}'
    try:
        response = requests.get(update_url, auth=HTTPBasicAuth(username, password))
        response.raise_for_status()
        print(f"Update response: {response.text}")
    except requests.RequestException as e:
        print(f"Error updating No-IP: {e}")

def main():
    while True:
        current_ip = get_public_ip()
        if current_ip:
            update_noip(current_ip)
        print(f"Waiting {update_interval} seconds before next update...")
        time.sleep(update_interval)

if __name__ == '__main__':
    main()

