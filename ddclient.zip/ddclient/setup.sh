#!/bin/bash

# Check if the script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root and also please move this ddclient on /root/ path  "
  exit 1
fi


# Step 1: Create and activate the virtual environment
python3 -m venv /root/ddclient/myenv
source /root/ddclient/myenv/bin/activate

# Step 2: Install the necessary Python packages
pip install requests

# Step 3: Copy the service file to the systemd directory
cp -r ddclient-update.service /etc/systemd/system/

# Step 4: Reload systemd to recognize the new service
systemctl daemon-reload

# Step 5: Enable the service to start on boot
systemctl enable ddclient-update.service

# Step 6: Start the service immediately
systemctl start ddclient-update.service

